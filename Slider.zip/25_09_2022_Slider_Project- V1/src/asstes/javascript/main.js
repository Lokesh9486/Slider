const sliderContainer=document.querySelector('.slider-container');
let sliderImage=Array.from(document.querySelectorAll('.slider-container img'))
const prev=document.querySelector('.prev');
const next=document.querySelector('.next');

let counter=1;

const firstClone=sliderImage[0].cloneNode(true);
const lastClone=sliderImage[sliderImage.length-1].cloneNode(true);
firstClone.id="firstClone";
lastClone.id="lastClone";
sliderContainer.append(firstClone);
sliderContainer.prepend(lastClone);

const imageWidth=firstClone.clientWidth;
sliderContainer.style=`transform:translateX(${-imageWidth}px)`;

next.addEventListener("click",()=>{
    counter++;
    sliderContainer.style=`transform:translateX(${-imageWidth*counter}px)`;
    sliderContainer.style.transition= '.3s linear';
})

prev.addEventListener("click",()=>{
    counter--;
    sliderContainer.style=`transform:translateX(${-imageWidth*counter}px)`;
    sliderContainer.style.transition= '.3s linear';
})

sliderContainer.addEventListener("transitionend",()=>{
    sliderImage=Array.from(document.querySelectorAll('.slider-container img'));
    if(sliderImage[counter].id==firstClone.id){
        sliderContainer.style.transition="none";
        counter=1;
        sliderContainer.style=`transform:translateX(${-imageWidth*counter}px)`;
    }
    if(sliderImage[counter].id==lastClone.id){
        sliderContainer.style.transition="none";
        counter=sliderImage.length-2;
        sliderContainer.style=`transform:translateX(${-imageWidth*counter}px)`;
    }
    
})