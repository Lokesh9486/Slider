const sliderContainer=document.querySelector('.slider-container');
const sliderImage=Array.from(document.querySelectorAll('.slider-container img'))
const prev=document.querySelector('.prev');
const next=document.querySelector('.next');
const numberContainer=document.querySelector('.number-container');

let counter=1;

const firstClone=sliderImage[0].cloneNode(true);
const lastClone=sliderImage[sliderImage.length-1].cloneNode(true);
firstClone.id="firstClone";
lastClone.id="lastClone";
sliderContainer.append(firstClone);
sliderContainer.prepend(lastClone);

const imageWidth=firstClone.clientWidth;
sliderContainer.style=`transform:translateX(${-imageWidth}px)`;

const slideNumberCalu=()=>{
    numberContainer.innerHTML=`${counter}/${sliderImage.length}`
}

slideNumberCalu();

next.addEventListener("click",()=>{
    counter++;
    sliderContainer.style=`transform:translateX(${-imageWidth*counter}px)`;
    sliderContainer.style.transition= '.3s linear';
    slideNumberCalu();
})

prev.addEventListener("click",()=>{
    counter--;
    sliderContainer.style=`transform:translateX(${-imageWidth*counter}px)`;
    sliderContainer.style.transition= '.3s linear';
    slideNumberCalu();
})

sliderContainer.addEventListener("transitionend",()=>{
   let sliderImage=Array.from(document.querySelectorAll('.slider-container img'));
    if(sliderImage[counter].id==firstClone.id){
        sliderContainer.style.transition="none";
        counter=1;
        sliderContainer.style=`transform:translateX(${-imageWidth*counter}px)`;
        slideNumberCalu();
    }
    if(sliderImage[counter].id==lastClone.id){
        sliderContainer.style.transition="none";
        counter=sliderImage.length-2;
        sliderContainer.style=`transform:translateX(${-imageWidth*counter}px)`;
        slideNumberCalu();
    }
    
})


