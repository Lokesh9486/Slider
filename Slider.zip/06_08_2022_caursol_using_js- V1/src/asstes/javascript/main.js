const carouselSilder=document.querySelector(".carousel-silder");
let carouselImages=document.querySelectorAll(".carousel-silder img");
const prev=document.querySelector(".prev");
const next=document.querySelector(".next");

let counter =1;
const firstClone=carouselImages[0].cloneNode(true);
const lastClone=carouselImages[carouselImages.length-1].cloneNode(true);
firstClone.id="first-clone";
lastClone.id="last-clone";
carouselSilder.append(firstClone);
carouselSilder.prepend(lastClone);
const size=carouselImages[0].clientWidth;

carouselSilder.style.transform="translateX("+(-size*counter)+"px)";

next.addEventListener("click",()=>{
  if(counter>=carouselImages.length-1)return;
  console.log(counter,carouselImages.length); 
  counter++;
  carouselSilder.style.transform="translateX("+(-size*counter)+"px)";
  carouselSilder.style.transition=" .7s";
})

prev.addEventListener("click",()=>{
  if(counter<=0)return;
  counter--;
  carouselSilder.style.transform="translateX("+(-size*counter)+"px)";
  carouselSilder.style.transition=" .7s";
})

carouselSilder.addEventListener("transitionend",()=>{
  carouselImages=document.querySelectorAll(".carousel-silder img");
  if(carouselImages[counter].id === firstClone.id){
    carouselSilder.style.transition="none";
      counter =1;
      carouselSilder.style.transform="translateX("+(-size*counter)+"px)";
    }
    if(carouselImages[counter].id === lastClone.id){
      carouselSilder.style.transition="none";
        counter =carouselImages.length-2;
        carouselSilder.style.transform="translateX("+(-size*counter)+"px)";
      }
})