const sliderImgContent=document.querySelector('.slider-img');
let sliderImges=document.querySelectorAll('.slider-img img');
const prev=document.querySelector('.prev');
const next=document.querySelector('.next');

const firstClone=sliderImges[0].cloneNode("true");
const lastClone=sliderImges[sliderImges.length-1].cloneNode("true");
firstClone.id="firstClone";
lastClone.id="lastClone";
firstClone.className='image-right';
lastClone.className='image-left';

sliderImgContent.append(firstClone);
sliderImgContent.prepend(lastClone);

sliderImges=document.querySelectorAll('.slider-img img');

let counter=1;

next.addEventListener("click",()=>{
    counter++;
    console.log(sliderImges.length,counter);
    if(sliderImges.length-1<=counter)return counter--;
    const currentSlider=document.querySelector('.current-slider');
    const nextToCurrentSlider=currentSlider.nextElementSibling;
    const prevToCurrentSlider=currentSlider.previousElementSibling.className;
    currentSlider.classList.replace("current-slider",prevToCurrentSlider)
    nextToCurrentSlider.classList.replace(nextToCurrentSlider.className,"current-slider");
})

prev.addEventListener("click",()=>{
    counter--;
    console.log(sliderImges.length,counter);
    if(counter<=0)return counter=0;
    const currentSlider=document.querySelector('.current-slider');
    const nextToCurrentSlider=currentSlider.nextElementSibling;
    const prevToCurrentSlider=currentSlider.previousElementSibling;
    currentSlider.classList.replace("current-slider",nextToCurrentSlider.className)
    prevToCurrentSlider.classList.replace(prevToCurrentSlider.className,"current-slider");
})